current finds: 
1383804548 - 62 Capacity - XY:14957,18654

Overview:
This is a simple cpp program made with cmake!
cmake is used to integrate the lua functions, and c++ to replicate the rng for Noita's wands.
Making fancy wands for new/consistent spawn offsets will be of great value as well! As this will provide new values.
The tool is meant to search seeds 1-4294967295 (Will stop at 4294967295+)
Please share interesting finds/bugs on the Noita Discord.
We hope to find the maximum capacity a wand can have!
Best of luck to you all! <3

Special Thanks To:
kaliuresis
TwoAbove
dextercd
NathanSkimScam
🍔🍔🍔
Y🍵


More info:

How to run: Go to `final_project/final_project.exe` and run it.
If you're getting error messages either you're preventing it from making output/input files, or the input file doesn't exist.


Editing: The `gun_procedural.lua` is pretty sensistive. Only make edits to `generate_gun` at the bottom of the file.
Rules for using these wand values: (Cost, Level, Force_Unshuffle) Below is the "Level: Cost" of the wand. 
If you make a LEVEL 10 wand increase level to 11, and if it's UNSHUFFLE subtract 20 from the cost 
(AKA DEFAULT VALUES = 11, 180, true )

1:  30
2:  40
3:  60
4:  80
5:  100
6:  120
10: 200

GitHub Source: https://github.com/ExtolsSuperSauce/final_project

About cmake: https://cmake.org/overview/
cmake is a system that integrates other libs/languages for c++

